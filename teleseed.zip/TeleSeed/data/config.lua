do local _ = {
  enabled_plugins = {
    "botmanager",
    "tabchisd",
    "echo"
  },
  moderation = {
    data = "data/moderation.json"
  },
  sudo_users = {
    113566842
  }
}
return _
end