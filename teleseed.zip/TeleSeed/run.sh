#!/bin/bash
while true; do
    bash launch.sh
done
